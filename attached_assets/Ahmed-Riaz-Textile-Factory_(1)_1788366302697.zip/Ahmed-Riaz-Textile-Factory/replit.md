# Ahmed Riaz Textile Factory

A database-backed B2B textile manufacturing website and protected admin CMS for Ahmed Riaz in Baldia, Karachi.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required admin secrets: `ADMIN_USERNAME` and `ADMIN_PASSWORD` — server-only login configuration

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/ahmed-riaz-textile/src/App.tsx` — public pages, detail pages, admin login, and CMS UI
- `artifacts/ahmed-riaz-textile/src/index.css` — warm textile visual system and responsive styles
- `artifacts/api-server/src/routes/content.ts` — public content, admin session, and protected CRUD routes
- `lib/db/src/schema/site.ts` — settings, stats, content, and hashed admin-session tables
- `lib/api-spec/openapi.yaml` — source of truth for the typed API client and Zod schemas

## Architecture decisions

- Public and admin surfaces share one content table and one typed API contract.
- Admin sessions use hashed random tokens in PostgreSQL and HttpOnly cookies; credentials are read only from Replit Secrets.
- Demo content is intentionally honest about scale and marks replaceable entries rather than inventing brands, dates, or machine models.
- Media is represented by paths and metadata in the database so the upload layer can be upgraded without changing content records.

## Product

- Public routes cover Home, About, Services, Our Excellence, Contact, and product/design detail pages.
- Admin routes cover login, dashboard counts, collection CRUD, publish/feature controls, and site settings.
- The public home page is backed by `/api/site` and updates when admin content changes.

## User preferences

- Never put the admin username or password in frontend code, the browser bundle, or committed source.

## Gotchas

- Admin login intentionally returns a configuration error until `ADMIN_USERNAME` and `ADMIN_PASSWORD` exist in Replit Secrets; there is no fallback credential.
- Contact details and some history entries are demo placeholders and should be replaced before publishing.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
